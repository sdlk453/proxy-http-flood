import socket
import requests
from requests import get
import os
from threading import Thread
from util.log import *
from time import sleep
import random
import getpass
import time
import sys
import getpass
import urllib
import json	
import requests as req
from requests.exceptions import ConnectionError


URL = 'https://api.proxyscrape.com/v2/?request=getproxies&protocol=all&timeout=10000&country=all&ssl=all&anonymity=all'
file = req.get(URL, allow_redirects=True)

open('proxies.txt', 'wb').write(file.content)

print ('Proxy download completed. Now run the proxy stored in proxies.txt in the proxy checker, fill in the working proxy in proxies.txt, save it, and then run phoenix.py.')