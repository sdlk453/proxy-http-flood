import os

print("""
discord weird#1337
""")

print("""[1] pip\n[2] pip3\nWhich one do you use?""")
rn = input(">>>")
if rn == '1':
    os.system("pip install speedtest-cli")
    os.system("pip install PySocks")
    os.system("pip install cfscrape")
    os.system("pip install datetime")
    os.system("pip install ssl")
    os.system("pip install threading")
    os.system("pip install imcplib")
    os.system("pip install scapy")
elif rn == '2':
    os.system("pip3 install speedtest-cli")
    os.system("pip3 install PySocks")
    os.system("pip3 install cfscrape")
    os.system("pip3 install datetime")
    os.system("pip3 install ssl")
    os.system("pip3 install threading")
    os.system("pip3 install imcplib")
    os.system("pip3 install scapy")
else:
    print("?")

os.system("sudo apt-get install nodejs")
os.system("sudo apt-get install npm")
os.system("npm i events")
os.system("npm i fs")
os.system("npm i url")
os.system("npm i net")
os.system("npm i cloudscraper")
os.system("npm i request")
os.system("npm i randomstring")
os.system("npm i cluster")
os.system("npm i cloudflare-bypasser")
os.system("npm i hcaptcha-solver")
os.system("ulimit -n 999999")
os.system("chmod +x *")
os.system("sudo python3 stanley.py")
